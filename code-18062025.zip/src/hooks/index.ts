export { default as useConfig } from './useConfig';
